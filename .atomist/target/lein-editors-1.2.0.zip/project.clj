(defproject com.atomist/sample "0.0.1-SNAPSHOT"
  :description "Simple Lein project"
  :dependencies [[org.clojure/clojure "1.8.0"]])
