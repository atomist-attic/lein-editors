# Lein Project Generator

<a href="https://api.atomist.com/v1/projects/generators/065e08ad-e208-4c63-9f63-2ebdb5a43990"><img src="https://images.atomist.com/button/create-project.png"/> </a>

<a href="https://api.atomist.com/v1/projects/editors/f527d560-3d59-4b89-a6bc-783477bbdaec"><img src="http://images.atomist.com/button/add-midje.png"/></a>
