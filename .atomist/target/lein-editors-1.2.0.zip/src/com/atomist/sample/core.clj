(ns com.atomist.sample.core)
